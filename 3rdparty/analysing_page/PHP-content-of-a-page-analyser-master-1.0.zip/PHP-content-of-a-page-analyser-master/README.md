# PHP content of a page analyser
Analysing the content of a page in PHP

This PHP project will allow you to analyse with your page the global content of another page. It would be useful for an easier integration of an external page in yours

Has been translateed in :

French
English
